// replace application with the name of your package
use finalchapter::game;

fn main() {
    #[allow(unused)]
    let mut game = game::Game::new();
}
